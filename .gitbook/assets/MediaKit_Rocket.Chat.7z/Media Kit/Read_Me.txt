Read our brand guidelines at: https://docs.rocket.chat/guides/brand-and-visual-guidelines
Find more elements for your content at: https://drive.google.com/drive/folders/1gaRMmpX2iuc8x9x5szbqdDSfaArjb19e?usp=sharing
Find more icons at: https://drive.google.com/drive/folders/1m097stjSL7k8FSYpbKV3_gvu83sPfeE2?usp=sharing

Rocket.Chat